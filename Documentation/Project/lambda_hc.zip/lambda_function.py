import json, boto3, pymysql, os
from botocore.exceptions import ClientError

def get_secret():
    # Dynamically fetched from the SECRET_ARN environment variable defined in Step 9 YAML
    secret_arn = os.environ.get('SECRET_ARN')
    client = boto3.client('secretsmanager', region_name=os.environ.get('AWS_REGION'))
    try:
        response = client.get_secret_value(SecretId=secret_arn)
        return json.loads(response['SecretString'])
    except Exception as e:
        print(f"Secret Error: {e}")
        raise e

def lambda_handler(event, context):
    db = None
    try:
        creds = get_secret()
        # Uses injected DB_HOST from Step 9 YAML, falling back to Secret host if missing
        db_host = os.environ.get('DB_HOST', creds.get('host'))
        
        # Establishing connection to the Aurora Cluster
        db = pymysql.connect(
            host=db_host, 
            user=creds['username'], 
            password=creds['password'],
            database='dctapp', 
            connect_timeout=3 # Increased slightly to handle cross-region latency if needed
        )
        
        with db.cursor() as cursor:
            # The core health check logic: identifies Primary vs. Secondary
            cursor.execute("SELECT @@innodb_read_only")
            is_read_only = cursor.fetchone()[0]
        
        return {
            "statusCode": 200,
            "body": json.dumps({
                "status": "healthy",
                "mode": "Read-Only" if is_read_only else "Write-Capable",
                "region": os.environ.get('AWS_REGION', 'unknown')
            })
        }
    except Exception as e:
        print(f"HEALTH CHECK FAILED: {str(e)}")
        # Returns 503 so Route 53 knows this region is "Unhealthy"
        return {"statusCode": 503, "body": json.dumps({"error": "unavailable", "detail": str(e)})}
    finally:
        if db: 
            db.close()