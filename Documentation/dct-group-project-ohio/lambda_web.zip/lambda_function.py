import json, boto3, pymysql, os
from botocore.exceptions import ClientError

REGION_NAME = os.environ.get('AWS_REGION', 'us-east-1')

def get_secret():
    # FIXED: Matches the names from Step 6.1 and 6.2
    secret_name = f"dct-{REGION_NAME}-aurora-secret"
    client = boto3.client('secretsmanager', region_name=REGION_NAME)
    try:
        response = client.get_secret_value(SecretId=secret_name)
        return json.loads(response['SecretString'])
    except ClientError as e:
        print(f"Error retrieving secret {secret_name}: {e}")
        raise e

def lambda_handler(event, context):
    path = event.get('path', '').lower()
    http_method = event.get('httpMethod', '').upper()
    headers = {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "POST,GET,OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type"
    }

    if http_method == "OPTIONS":
        return {"statusCode": 200, "headers": headers, "body": ""}

    try:
        creds = get_secret()
        # Favors the environment variable from CloudFormation Step 8
        db_host = os.environ.get('DB_HOST', creds.get('host'))
        
        db = pymysql.connect(
            host=db_host, 
            user=creds['username'], 
            password=creds['password'],
            database='dctapp', 
            connect_timeout=5, 
            autocommit=True,
            cursorclass=pymysql.cursors.DictCursor
        )
        
        with db.cursor() as cursor:
            # Session consistency for secondary regions (Ohio)
            if REGION_NAME != 'us-east-1':
                cursor.execute("SET SESSION aurora_replica_read_consistency = 'SESSION';")

            if "submit" in path and http_method == "POST":
                body = json.loads(event.get('body', '{}'))
                cursor.execute("INSERT INTO submissions (name, message) VALUES (%s, %s)", 
                              (body.get('name', 'Anonymous'), body.get('message', 'No message')))
                return {"statusCode": 200, "headers": headers, "body": json.dumps({"message": "Saved!", "region": REGION_NAME})}

            elif "retrieve" in path:
                cursor.execute("SELECT name, message, created_at FROM submissions ORDER BY created_at DESC LIMIT 10")
                results = cursor.fetchall()
                for row in results:
                    if 'created_at' in row: row['created_at'] = str(row['created_at'])
                return {"statusCode": 200, "headers": headers, "body": json.dumps({"data": results, "region": REGION_NAME})}

            elif "region" in path:
                return {"statusCode": 200, "headers": headers, "body": json.dumps({"region": REGION_NAME})}

        return {"statusCode": 404, "headers": headers, "body": json.dumps({"error": "Path Not Found"})}
        
    except Exception as e:
        print(f"Unhandled Exception: {str(e)}")
        return {"statusCode": 500, "headers": headers, "body": json.dumps({"error": str(e)})}
    finally:
        if 'db' in locals() and db: db.close()
